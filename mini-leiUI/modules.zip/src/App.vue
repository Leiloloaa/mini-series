<template>
  <div class="container">
    <L-carousel
      :autoplay="true"
      :duration="3000"
      :initial="0"
      :hasDot="true"
      :hasDirector="true"
    >
      <L-carousel-item
        v-for="(item,index) of itemData"
        :key="index"
      >
        <img
          :src="`./src/assets/image/${item.image_name}`"
          alt=""
        >
      </L-carousel-item>
    </L-carousel>
  </div>
</template>

<script lang="ts" setup>
import itemData from "./assets/data";
</script>

<style scoped>
.container {
  width: 520px;
  height: 280px;
  margin: 150px 0;
}
</style>