import { createApp } from 'vue';
import App from './App.vue';
import LeiUI from '../modules/L-ui/index';

createApp(App).use(LeiUI).mount('#app');