export default [
    { image_name: '1.JPG' },
    { image_name: '2.JPG' },
    { image_name: '3.JPG' },
]