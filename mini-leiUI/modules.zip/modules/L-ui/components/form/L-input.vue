<template>
  <input
    type="text"
    name=""
    id=""
  >
</template>

<script lang='ts' >
export default {
  name: "LInput",
};
</script>
<style lang='less' scoped>
</style>