<template>
  <button>按钮</button>
</template>

<script lang='ts'>
export default {
  name: "LButton",
};
</script>
<style lang='less' scoped>
</style>